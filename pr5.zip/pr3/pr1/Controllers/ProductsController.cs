﻿using Microsoft.AspNetCore.Mvc;
using pr1.Models;

public class ProductsController : Controller
{
    private readonly Db33Context _db;

    public ProductsController(Db33Context context)
    {
        _db = context;
    }

    public IActionResult Index()
    {
        var products = _db.Products.ToList();
        return View(products);
    }

    [HttpPost]
    public IActionResult AddToCart(int productId)
    {
        int? userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null)
            return RedirectToAction("Login", "Account");

        int currentUserId = userId.Value;

        var cart = _db.Carts.FirstOrDefault(c => c.UuserId == currentUserId);
        if (cart == null)
        {
            cart = new Cart
            {
                UuserId = currentUserId,
                CreationDate = DateTime.Now
            };
            _db.Carts.Add(cart);
            _db.SaveChanges();
        }

        var cartItem = _db.CartItems.FirstOrDefault(ci => ci.CartId == cart.IdCart && ci.ProductId == productId);
        if (cartItem != null)
            cartItem.Quantity++;
        else
        {
            cartItem = new CartItem
            {
                CartId = cart.IdCart,
                ProductId = productId,
                Quantity = 1
            };
            _db.CartItems.Add(cartItem);
        }
        _db.SaveChanges();

        return RedirectToAction("Index", "Cart");
    }
}