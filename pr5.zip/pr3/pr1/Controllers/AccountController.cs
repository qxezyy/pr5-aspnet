﻿using Microsoft.AspNetCore.Mvc;
using pr1.Models;
using System.Text; //  для Encoding.UTF8 (при хешировании пароля).

public class AccountController : Controller
{
    private readonly Db33Context _db;

    public AccountController(Db33Context context)
    {
        _db = context;
    }

    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(string login, string password)
    {
        if (!_db.Users.Any(u => u.LoginUser == "test"))
        {
            var testUser = new User
            {
                LoginUser = "test",
                PasswordUser = HashPassword("123"),
                RoleId = 2,
                Email = "test@test.com",
                RegistrationDate = DateTime.Now
            };
            _db.Users.Add(testUser);
            _db.SaveChanges();
        }

        var user = _db.Users.FirstOrDefault(u => u.LoginUser == login);
        if (user != null && VerifyPassword(password, user.PasswordUser))
        {
            HttpContext.Session.SetInt32("UserId", user.IdUser);
            HttpContext.Session.SetString("UserName", user.LoginUser);
            return RedirectToAction("Index", "Products");
        }

        ViewBag.Error = "Неверный логин или пароль";
        return View();
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Products");
    }

    private bool VerifyPassword(string plainPassword, string storedHash)
    {
        string salt = storedHash.Substring(0, 64);
        string expectedHash = storedHash.Substring(64);
        string salted = plainPassword + salt;
        using (var sha256 = System.Security.Cryptography.SHA256.Create())
        {
            byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(salted));
            string computedHash = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            return computedHash == expectedHash;
        }
    }

    private string HashPassword(string plainPassword)
    {
        string salt = GenerateSalt();
        string salted = plainPassword + salt;
        using (var sha256 = System.Security.Cryptography.SHA256.Create())
        {
            byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(salted));
            string hash = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            return salt + hash;
        }
    }

    private string GenerateSalt()
    {
        string guid = Guid.NewGuid().ToString();
        using (var sha256 = System.Security.Cryptography.SHA256.Create())
        {
            byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(guid));
            return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
        }
    }
}