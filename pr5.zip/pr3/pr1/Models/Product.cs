﻿using System;
using System.ComponentModel.DataAnnotations;
using pr1.ValidationAttributes;

namespace pr1.Models;

public partial class Product
{
    public int IdProduct { get; set; }

    [Required(ErrorMessage = "Название обязательно")]
    [StringLength(50, MinimumLength = 3)]
    public string Title { get; set; } = null!;

    [Required(ErrorMessage = "Цена обязательна")]
    [PositivePrice]
    public decimal Price { get; set; }

    [Required(ErrorMessage = "Выберите категорию")]
    public int CategoryId { get; set; }

    [FutureDate]
    public DateTime RegistrationDate { get; set; }

    [StringLength(200)]
    public string? DescriptionProduct { get; set; }
}