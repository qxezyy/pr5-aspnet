﻿namespace pr1.Models
{
    public class CartItemViewModel
    {
        public int IdCartitem { get; set; }
        public int ProductId { get; set; }
        public string ProductTitle { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public decimal Total { get; set; }
    }
}