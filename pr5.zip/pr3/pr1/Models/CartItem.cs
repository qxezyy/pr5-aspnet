﻿using System;
using System.Collections.Generic;

namespace pr1.Models;

public partial class CartItem
{
    public int IdCartitem { get; set; }

    public int CartId { get; set; }

    public int ProductId { get; set; }

    public int Quantity { get; set; }
}
