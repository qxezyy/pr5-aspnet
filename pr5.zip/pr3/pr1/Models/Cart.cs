﻿using System;
using System.Collections.Generic;

namespace pr1.Models;

public partial class Cart
{
    public int IdCart { get; set; }

    public int UuserId { get; set; }

    public DateTime CreationDate { get; set; }

    public DateTime? UpdateDate { get; set; }
}
