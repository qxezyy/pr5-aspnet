﻿using System.ComponentModel.DataAnnotations;
using System.Linq;
namespace pr1.ValidationAttributes
{
    public class PasswordDigitAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
                return ValidationResult.Success;

            string password = value.ToString();
            if (!password.Any(char.IsDigit))
                return new ValidationResult("Пароль должен содержать хотя бы одну цифру.");

            return ValidationResult.Success;
        }
    }
}
