﻿using System.ComponentModel.DataAnnotations;
namespace pr1.ValidationAttributes
{
    public class LoginMinLengthAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
                return ValidationResult.Success;

            string login = value.ToString();
            if (login.Length < 5)
                return new ValidationResult("Логин должен содержать не менее 5 символов.");

            return ValidationResult.Success;
        }
    }
}