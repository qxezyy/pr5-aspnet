﻿using System;
using System.ComponentModel.DataAnnotations;
namespace pr1.ValidationAttributes
{
    public class FutureDateAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
                return ValidationResult.Success;

            DateTime date = (DateTime)value;
            if (date > DateTime.Today)
                return new ValidationResult("Дата не может быть в будущем.");

            return ValidationResult.Success;
        }
    }
}